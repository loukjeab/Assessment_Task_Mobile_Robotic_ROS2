# Package: mobile_robotic_course_assessment_task_2023

## Student Information
- Name: Peeranut Noonurak
- Matriculation No.: 7023582

## Package Overview
This ROS2 package aims to fulfill the requirements of the Mobile Robotics Course Assessment Task. It provides a comprehensive solution for simulating and controlling a mobile robot using ROS2 and Gazebo. The key features of this package include:

1. Simulation Environment: The package includes a predefined Gazebo world file (`smaze2d.world`) that provides a suitable environment for testing the mobile robot.

2. Robot Description: The robot's physical characteristics and structure are defined in a URDF file (`8th_car_sensor_2wheel_1castor_camera_collision.urdf`). This file includes detailed information about the robot's joints, links, and sensors.

3. Controllers: The package implements two controllers for the robot. The `joint_state_broadcaster` controller is responsible for publishing the robot's joint states, while the `simple_diff_drive_controller` handles the differential drive control for the robot's wheels.

4. Launch Files: The package provides a launch file (`assessment_task.launch.py`) that launches the necessary nodes and configurations to run the simulation. The launch file includes the Gazebo simulator, the robot state publisher, the robot spawn node, and RViz for visualization.

5. RViz Configuration: The package includes an RViz configuration file (`simple_robot_nav2_original.rviz`) that provides a preconfigured setup for visualizing the robot's data in RViz.


